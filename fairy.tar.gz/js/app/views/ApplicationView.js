define([
    'backbone',
    'router/ApplicationRouter',
    'views/abstract/AbstractView',
    'modules/FairyStory'
], function(
    Backbone,
    ApplicationRouter,
    AbstractView,
    FairyStory
){
    var ApplicationView=AbstractView.extend({

        el: 'body',

        router: null,

        game: null,

        initialize: function(){
            this.cid='application_view';

            AbstractView.prototype.initialize.call(this);

            this.render();
        },
        
        render: function(){
            this.initRouter();
            this.initGame();
        },

        setURL: function(url){
            Backbone.history.navigate('#'+url);
        },

        initRouter: function(){
            this.router=new ApplicationRouter({ view: this });
            Backbone.history.start({ pushState: false });
        },

        initGame: function(){
            this.game = new FairyStory({
                width: 1280,
                height: 720,
                storyId: 1
            });
        }
    });

    return ApplicationView;
});