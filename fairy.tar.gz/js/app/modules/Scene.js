define([

], function(

){
    function Scene(settings){
        var defaults={
            story: null,
        };
        
        var scene={
            settings: {},

            DOM: {},

            story: null,

            container: null,
            
            init: function(settings, defaults){
                _.bindAll.apply(_, [this].concat(_.functions(this)));

                $.extend(this.settings, defaults, settings);

                this.setup();
            },

            setup: function(){
                this.story = this.settings.story;

                this.container = this.story.add.group();
            },

            createBackground: function(asset){
                this.background = this.story.add.sprite(0, 0, asset);

                this.container.add(this.background);
            },

            
        };
        
        if(typeof settings === "undefined"){
            settings=defaults;
        }

        scene.init(settings, defaults);
        
        return scene;
    }

    return Scene;
});