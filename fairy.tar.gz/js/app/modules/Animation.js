define([
    'TweenMax'
], function(
    TweenMax
){
    function Animation(settings){
        var defaults={

        };
        
        var animation={
            settings: {},

            init: function(settings, defaults){
                _.bindAll.apply(_, [this].concat(_.functions(this)));

                $.extend(this.settings, defaults, settings);

                this.setup();
            },

            setup: function(){

            },

            rotation: function(_params){
                var params = {};
                var defaults = {
                    element: null,
                    time: 1,
                    min: 0,
                    max: 0,
                    repeat: 0,
                    yoyo: false,
                    ease: Linear.easeNone,
                    onStart: function(){},
                    onComplete: function(){}
                };

                $.extend(params, defaults, _params);

                TweenMax.killTweensOf(params.element);

                TweenMax.set(params.element, {
                    angle: params.min
                });

                TweenMax.to(params.element, params.time, {
                    ease: params.ease,
                    delay: params.delay,
                    repeatDelay: params.repeatDelay,
                    angle: params.max,
                    repeat: params.repeat,
                    yoyo: params.yoyo,
                    onStart: function(){
                        params.onStart();
                    },
                    onComplete: function(){
                        params.onComplete();
                    }
                });
            },

            eyes: function(params){
                var t = { d: 0 };

                var openEyes = function(){
                    params.open.alpha = 1;
                    params.closed.alpha = 0;
                };

                var closeEyes = function(){
                    params.open.alpha = 0;
                    params.closed.alpha = 1;
                };

                var animator = function(){
                    var openTime = params.openTime;
                    var closedTime = params.closedTime;

                    openTime += (Math.random() * params.randomness);
                    closedTime += (Math.random() * params.randomness);


                    openEyes();

                    TweenMax.to(t, openTime, {
                        d: 1,
                        onComplete: function(){
                            closeEyes();

                            TweenMax.to(t, closedTime, {
                                d: 2,
                                onComplete: function(){
                                    closeEyes();
                                    animator();
                                }
                            });
                        }
                    });    
                };

                
                animator();
            }
        };
        
        if(typeof settings === "undefined"){
            settings=defaults;
        }

        animation.init(settings, defaults);
        
        return animation;
    }

    return Animation;
});