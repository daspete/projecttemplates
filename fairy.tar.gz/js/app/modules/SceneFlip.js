define([

], function(

){
    function SceneFlip(settings){
        var defaults={
            story: null,
            front: null,
            back: null,

            flipTime: 1
        };
        
        var scene_flip={
            settings: {},

            DOM: {},

            frontSprite: null,
            backSprite: null,
            
            init: function(settings, defaults){
                _.bindAll.apply(_, [this].concat(_.functions(this)));

                $.extend(this.settings, defaults, settings);

                this.setup();
            },

            setup: function(){
                this.frontSprite = this.settings.story.make.sprite(0,0,this.settings.front);
                this.backSprite = this.settings.story.make.sprite(0,0,this.settings.back);

                this.frontSprite.crop(new Phaser.Rectangle(this.frontSprite.width / 2,0,this.frontSprite.width, this.frontSprite.height));

                this.settings.story.world.add(this.frontSprite);

            }
        };
        
        if(typeof settings === "undefined"){
            settings=defaults;
        }

        scene_flip.init(settings, defaults);
        
        return scene_flip;
    }

    return SceneFlip;
});