define([
    'views/ApplicationView'
], function(
    ApplicationView
){
    var application_view=new ApplicationView();
});