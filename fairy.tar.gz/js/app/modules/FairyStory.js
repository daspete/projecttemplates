define([
    'modules/Scene',
    'modules/Animation',
    'modules/SceneFlip',
    'TweenMax',
    'phaser',
    'datGUI'
], function(
    Scene,
    Animation,
    SceneFlip,
    TweenMax,
    Phaser,
    dat
){
    function FairyStory(settings){
        var defaults={
            width: 1280,
            height: 720,
            storyId: 1
        };
        
        var fairy_story={
            settings: {},

            DOM: {},

            story: null,

            animation: null,

            scenes: {},

            currentScene: 1,
            
            init: function(settings, defaults){
                _.bindAll.apply(_, [this].concat(_.functions(this)));

                $.extend(this.settings, defaults, settings);

                this.setup();
            },

            setup: function(){
                // CREATE PHASER CANVAS

                this.ui = new dat.GUI();
                this.animation = new Animation();

                this.story = new Phaser.Game(this.settings.width, this.settings.height, Phaser.AUTO, 'story', {
                    preload: this.preload,
                    create: this.create
                });
            },

            preload: function(){
                this.loadScene1();
                this.loadScene2();
                this.loadScene3();
                this.loadScene4();
                this.loadScene5();
                this.loadScene6();
                this.loadScene7();
                this.loadScene8();
                this.loadScene9();
            },

            create: function(){
                this.autoScale();

                this.createScenes();

                this.startStory();
            },

            startStory: function(){
                this.startScene1();

                this.flipPage(2);
            },


            loadScene1: function(){
                this.story.load.atlas('scene1', 'assets/images/story1/sprites/scene1.png', 'assets/spritesheets/story1/scene1.json');
                this.story.load.image('scene1background', 'assets/images/story1/backgrounds/scene1.jpg');
            },
            loadScene2: function(){
                this.story.load.atlas('scene2', 'assets/images/story1/sprites/scene2.png', 'assets/spritesheets/story1/scene2.json');
                this.story.load.image('scene2background', 'assets/images/story1/backgrounds/scene2.jpg');
            },
            loadScene3: function(){
                this.story.load.atlas('scene3', 'assets/images/story1/sprites/scene3.png', 'assets/spritesheets/story1/scene3.json');
                this.story.load.image('scene3background', 'assets/images/story1/backgrounds/scene3.jpg');
            },
            loadScene4: function(){
                this.story.load.atlas('scene4', 'assets/images/story1/sprites/scene4.png', 'assets/spritesheets/story1/scene4.json');
                this.story.load.image('scene4background', 'assets/images/story1/backgrounds/scene4.jpg');
            },
            loadScene5: function(){
                this.story.load.atlas('scene5', 'assets/images/story1/sprites/scene5.png', 'assets/spritesheets/story1/scene5.json');
                this.story.load.image('scene5background', 'assets/images/story1/backgrounds/scene5.jpg');
            },
            loadScene6: function(){
                this.story.load.atlas('scene6', 'assets/images/story1/sprites/scene6.png', 'assets/spritesheets/story1/scene6.json');
                this.story.load.image('scene6background', 'assets/images/story1/backgrounds/scene6.jpg');
            },
            loadScene7: function(){
                this.story.load.atlas('scene7', 'assets/images/story1/sprites/scene7.png', 'assets/spritesheets/story1/scene7.json');
                this.story.load.image('scene7background', 'assets/images/story1/backgrounds/scene7.jpg');
            },
            loadScene8: function(){
                this.story.load.atlas('scene8', 'assets/images/story1/sprites/scene8.png', 'assets/spritesheets/story1/scene8.json');
                this.story.load.image('scene8background', 'assets/images/story1/backgrounds/scene8.jpg');
            },
            loadScene9: function(){
                this.story.load.atlas('scene9', 'assets/images/story1/sprites/scene9.png', 'assets/spritesheets/story1/scene9.json');
            },

            createScenes: function(){
                for(var i = 1; i < 10; i++){
                    this.scenes['scene' + i] = new Scene({
                        story: this.story
                    });

                    this['initScene' + i](this.scenes['scene' + i]);
                }
            },

            initScene1: function(scene){
                scene.createBackground('scene1background');

                this.createScene1Leo();
                this.createScene1Lamp();
            },

            initScene2: function(scene){
                scene.createBackground('scene2background');  
            },
            initScene3: function(scene){
                scene.createBackground('scene3background');  
            },
            initScene4: function(scene){
                scene.createBackground('scene4background');
            },
            initScene5: function(scene){
                scene.createBackground('scene5background');
            },
            initScene6: function(scene){
                scene.createBackground('scene6background');
            },
            initScene7: function(scene){
                scene.createBackground('scene7background');
            },
            initScene8: function(scene){
                scene.createBackground('scene8background');
            },
            initScene9: function(scene){
                
            },

            createScene1Leo: function(){
                var scene = this.scenes.scene1;

                scene.leo = {
                    body: this.story.add.sprite(0,0,'scene1','leo-body.png'),
                    head: {
                        head: this.story.add.sprite(0,0,'scene1','leo-head.png'),
                        brow: {
                            left: this.story.add.sprite(0,0, 'scene1', 'leo-eye-brow-left.png'),
                            right: this.story.add.sprite(0,0, 'scene1', 'leo-eye-brow-right.png')
                        },
                        eyes: {
                            open: this.story.add.sprite(0,0, 'scene1', 'leo-eyes-open.png'),
                            closed: this.story.add.sprite(0,0, 'scene1', 'leo-eyes-close.png')
                        }
                    }
                };

                scene.leoElement = this.story.add.group(scene.container);
                scene.leoElement.add(scene.leo.body);

                scene.leoHead = this.story.add.group(scene.leoElement);
                scene.leoHead.add(scene.leo.head.head);
                scene.leoHead.add(scene.leo.head.brow.left);
                scene.leoHead.add(scene.leo.head.brow.right);
                scene.leoHead.add(scene.leo.head.eyes.closed);
                scene.leoHead.add(scene.leo.head.eyes.open);

                scene.leoElement.x = 1000.0;
                scene.leoElement.y = 250.0;

                scene.leoHead.x = 150.0;
                scene.leoHead.y = -1;

                scene.leoHead.pivot.x = scene.leo.head.head.width * 0.4;
                scene.leoHead.pivot.y = scene.leo.head.head.height * 0.9;

                scene.leo.head.brow.left.x = 23;
                scene.leo.head.brow.left.y = 60;

                scene.leo.head.brow.right.x = 66;
                scene.leo.head.brow.right.y = 60;

                scene.leo.head.eyes.open.x = 15;
                scene.leo.head.eyes.open.y = 75;

                scene.leo.head.eyes.closed.x = 11;
                scene.leo.head.eyes.closed.y = 72;
                scene.leo.head.eyes.closed.alpha = 0;

                scene.container.add(scene.leoElement);
            },

            createScene1Lamp: function(){
                var that = this;
                var scene = this.scenes.scene1;

                scene.lamp = {
                    lamp: this.story.add.sprite(0,0,'scene1', 'lamp.png'),
                    glow: this.story.add.sprite(0,0, 'scene1', 'glow.png')
                    
                };

                scene.lampElement = this.story.add.group(scene.container);

                scene.lampElement.add(scene.lamp.lamp);
                scene.lampElement.add(scene.lamp.glow);

                scene.lampElement.x = 300;
                scene.lampElement.pivot.x = scene.lamp.lamp.width * 0.4;

                scene.lamp.glow.x = -67;
                scene.lamp.glow.y = 36;
                scene.lamp.glow.alpha = 0;

                scene.lamp.lamp.inputEnabled = true;
                scene.lamp.lamp.input.useHandCursor = true;
                scene.lamp.lamp.events.onInputDown.add(function(){
                    that.animation.rotation({
                        element: scene.lampElement,
                        time: 2.5,
                        min: 30,
                        max: 0,
                        ease: Elastic.easeOut,
                        onStart: function(){
                            scene.lamp.glow.alpha = (scene.lamp.glow.alpha === 0) ? 1 : 0;
                        },
                        onComplete: function(){
                            
                        }
                    });
                }, this);
            },
            

            startScene1: function(){
                //TODO:: RESET ANIMATIONS
                //TODO:: START ANIMATIONS

                var scene = this.scenes.scene1;

                this.animation.rotation({
                    element: scene.leoHead,
                    delay: 1,
                    repeatDelay: 1,
                    time: 2,
                    min: -20,
                    max: 20,
                    repeat: -1,
                    yoyo: true
                });

                this.animation.eyes({
                    open: scene.leo.head.eyes.open,
                    closed: scene.leo.head.eyes.closed,
                    openTime: 1,
                    closedTime: 0.1,
                    randomness: 0.2
                });

                this.story.world.bringToTop(this.scenes.scene1.container);
            },
            startScene2: function(){
                //TODO:: RESET ANIMATIONS
                //TODO:: START ANIMATIONS


                this.story.world.bringToTop(this.scenes.scene2.container);
            },
            startScene3: function(){
                //TODO:: RESET ANIMATIONS
                //TODO:: START ANIMATIONS


                this.story.world.bringToTop(this.scenes.scene3.container);
            },
            startScene4: function(){
                //TODO:: RESET ANIMATIONS
                //TODO:: START ANIMATIONS


                this.story.world.bringToTop(this.scenes.scene4.container);
            },
            startScene5: function(){
                //TODO:: RESET ANIMATIONS
                //TODO:: START ANIMATIONS


                this.story.world.bringToTop(this.scenes.scene5.container);
            },
            startScene6: function(){
                //TODO:: RESET ANIMATIONS
                //TODO:: START ANIMATIONS


                this.story.world.bringToTop(this.scenes.scene6.container);
            },
            startScene7: function(){
                //TODO:: RESET ANIMATIONS
                //TODO:: START ANIMATIONS


                this.story.world.bringToTop(this.scenes.scene7.container);
            },
            startScene8: function(){
                //TODO:: RESET ANIMATIONS
                //TODO:: START ANIMATIONS


                this.story.world.bringToTop(this.scenes.scene8.container);
            },
            startScene9: function(){
                //TODO:: RESET ANIMATIONS
                //TODO:: START ANIMATIONS


                this.story.world.bringToTop(this.scenes.scene9.container);
            },



            flipPage: function(nextScene){
                var flipper = new SceneFlip({
                    story: this.story,
                    front: this.scenes['scene' + this.currentScene].container.generateTexture(),
                    back: this.scenes['scene' + nextScene].container.generateTexture()
                });
            },


            autoScale: function(){
                this.story.scale.scaleMode = Phaser.ScaleManager.RESIZE;//USER_SCALE;//RESIZE;//EXACT_FIT;//SHOW_ALL;
                this.story.scale.pageAlignHorizontally = true;
                this.story.scale.pageAlignVertically = true;
            }
        };
        
        if(typeof settings === "undefined"){
            settings = defaults;
        }

        fairy_story.init(settings, defaults);
        
        return fairy_story;
    }

    return FairyStory;
});